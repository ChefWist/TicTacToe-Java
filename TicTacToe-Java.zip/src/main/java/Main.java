import java.util.Scanner;
import java.util.Arrays;


public class Main {

  static void show(int[][] showing) {
     for (int i = 0; i < showing.length; i++) {
       System.out.println(Arrays.toString(showing[i]));
     }
  }

  static int Ai() {
    return (int) (Math.random() * 9);
  }

  static int winner(int[][] showing) {
    if (showing[0][0] == 1 && showing[0][1] == 1 && showing[0][2] == 1) {
      return 1;
    } else if (showing[0][0] == 2 && showing[0][1] == 2 && showing[0][2] == 2) {
      return 0;
    } else if (showing[1][0] == 1 && showing[1][1] == 1 && showing[1][2] == 1) {
      return 1;
    } else if (showing[1][0] == 2 && showing[1][1] == 2 && showing[1][2] == 2) {
      return 0;
    } else if (showing[2][0] == 1 && showing[2][1] == 1 && showing[2][2] == 1) {
      return 1;
    } else if (showing[2][0] == 2 && showing[2][1] == 2 && showing[2][2] == 2) {
      return 0;
    } else if (showing[0][0] == 1 && showing[1][0] == 1 && showing[1][0] == 1) {
      return 1;
    } else if (showing[0][1] == 2 && showing[1][1] == 2 && showing[2][0] == 2) {
      return 0;
    } else if (showing[0][2] == 2 && showing[1][2] == 2 && showing[2][2] == 2) {
      return 0;
    } else if (showing[0][2] == 1 && showing[1][2] == 1 && showing[2][2] == 1) {
      return 1;
    } else if (showing[0][0] == 2 && showing[1][1] == 2 && showing[2][2] == 2) {
      return 0;
    } else if (showing[0][0] == 1 && showing[1][1] == 1 && showing[2][2] == 1) {
      return 1;
    } else if (showing[0][2] == 2 && showing[1][1] == 2 && showing[2][0] == 2) {
      return 0;
    } else if (showing[0][2] == 1 && showing[1][1] == 1 && showing[2][0] == 1) {
      return 1;
    } else {
      return 2;
    }
  }

  static int checkDraw(int[][] showing) {
    if (showing[0][0] != 0 && showing[0][1] != 0 && showing[0][2] != 0 && showing[1][0] != 0 && showing[1][1] != 0 && showing[1][2] != 0 && showing[2][0] != 0 && showing[2][1] != 0 && showing[2][2] != 0) {
      return 1;
    } else 
      return 0;
  }
  
 
  public static void main(String[] args) {
    int[][] screen = {{0,0,0},{0,0,0},{0,0,0}};
    int[][] allIndex = {{1,2,3},{4,5,6},{7,8,9}};
    Scanner input = new Scanner(System.in);
    int choice = 0; 
    int idx;
    int ai = 0;
    boolean running = true;
    int status;
    String answer;
    
    while (running) {
      show(allIndex);
      System.out.println(" ");
      show(screen);
      System.out.println("Choose an index:");
      choice = input.nextInt();
      
      idx = 0;
      for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++){
          if (idx == choice - 1 && screen[i][j] == 0) {
            screen[i][j] = 1;
          }
          idx++;
        }
      }

      ai = Ai();
      idx = 0;
      for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++){
          if (idx == ai - 1 && screen[i][j] == 0) {
            screen[i][j] = 2;
          }
          idx++;
        }
      }

      status = winner(screen);
      if (status == 1) {
        System.out.println("You won!");
        running = true;
      } else if (status == 0) {
        System.out.println("You lost!");
        running = false;
      }

      status = checkDraw(screen);
      if (status == 1) {
        System.out.println("Draw!");
        running = false;
      }
      
    }

    System.out.println("Play Again? (Y/N)");
    answer = input.next();
    if (answer == "Y") {
      running = true;
    } 
    
  }
}